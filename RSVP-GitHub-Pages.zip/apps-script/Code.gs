/**
 * RSVP PERKAHWINAN ALYN & SYARIFUDDIN — 12 DISEMBER 2026
 * Tampal keseluruhan fail ini ke Code.gs dalam Google Apps Script.
 * ID spreadsheet sudah diisi. Tambah fail HTML bernama Index, jalankan setup(), kemudian deploy.
 * Execute as: Me. Who has access: Anyone.
 * Backend menyokong laman GitHub Pages, Sites dan Index HTML dalam Apps Script.
 * GitHub Pages menghantar RSVP melalui doPost dan membaca pengesahan/ucapan melalui doGet.
 */

const SPREADSHEET_ID = '1Lwhguvd_Q2paT3ciJvbxJaLcKk9BoyLJMYUh5oBQFEg';
const SHEET_NAME = 'RSVP';
const HEADERS = ['ID kiriman', 'Tarikh dihantar', 'Nama', 'Status kehadiran', 'Jumlah hadir', 'Ucapan', 'Paparkan ucapan'];

/** Jalankan sekali di editor untuk menyediakan tab dan memberi kebenaran. */
function setup() {
  const sheet = getSheet_();
  sheet.setFrozenRows(1);
  sheet.getRange(1, 1, 1, HEADERS.length)
    .setBackground('#dceaf7').setFontColor('#354f66').setFontWeight('bold');
  sheet.setColumnWidth(2, 170);
  sheet.setColumnWidth(3, 210);
  sheet.setColumnWidth(4, 145);
  sheet.setColumnWidth(6, 400);
  sheet.getRange('B2:B').setNumberFormat('dd/MM/yyyy HH:mm:ss');
  sheet.getRange('E2:E').setNumberFormat('0');
  sheet.getRange('F2:F').setWrap(true);
  SpreadsheetApp.openById(SPREADSHEET_ID).setSpreadsheetTimeZone('Asia/Kuala_Lumpur');
  Logger.log('Tab RSVP siap. Deploy sebagai Web App dan salin URL berakhir /exec.');
}

/** Backend utama yang diminta: semua permintaan Google Sheets melalui doGet. */
function doGet(e) {
  const p = (e && e.parameter) || {};
  try {
    if (!p.action) {
      try {
        return HtmlService.createHtmlOutputFromFile('Index')
          .setTitle('The Wedding of Alyn & Syarifuddin')
          .addMetaTag('viewport', 'width=device-width, initial-scale=1');
      } catch (_) {
        return json_({ ok: true, service: 'RSVP Alyn & Syarifuddin', actions: ['list', 'submit', 'status'] });
      }
    }
    const expectedKey = PropertiesService.getScriptProperties().getProperty('RSVP_API_KEY');
    if (expectedKey && p.key !== expectedKey) fail_('Kiriman ini tidak dapat diterima.');
    if (p.callback && p.action !== 'list' && p.action !== 'status') fail_('Permintaan tidak sah.');
    let result;
    if (p.action === 'submit') result = saveRSVP_(p);
    else if (p.action === 'list') result = listWishes_(p);
    else if (p.action === 'status') result = readReceipt_(p);
    else result = { ok: true, service: 'RSVP Alyn & Syarifuddin', actions: ['submit', 'list', 'status'] };
    return browserReply_(result, p.callback);
  } catch (error) {
    return browserReply_(publicError_(error), p.callback);
  }
}

/** GitHub Pages sends a regular form POST; it never treats a no-cors response as success. */
function doPost(e) {
  const p = (e && e.parameter) || {};
  let result;
  try {
    if (p.action !== 'submit' || !validTicket_(p.ticket)) fail_('Permintaan tidak sah.');
    const key = PropertiesService.getScriptProperties().getProperty('RSVP_API_KEY');
    if (key && p.key !== key) fail_('Kiriman ini tidak dapat diterima.');
    if (p.website) fail_('Kiriman ini tidak dapat diterima.');
    result = saveRSVP_(p);
  } catch (error) { result = publicError_(error); }
  if (validTicket_(p.ticket)) {
    try {
      // The random ticket is separate from the public wish ID and contains no guest data.
      CacheService.getScriptCache().put('rsvp-receipt:' + p.ticket, JSON.stringify(result), 600);
    } catch (_) {
      // If temporary confirmation storage is unavailable, the client keeps the result unconfirmed.
      // Retrying the same requestId remains safe because saveRSVP_ prevents duplicate records.
    }
  }
  return json_(result);
}

function validTicket_(ticket) {
  return typeof ticket === 'string' && /^[a-f0-9]{32}$/.test(ticket);
}

function readReceipt_(p) {
  if (!validTicket_(p.ticket)) fail_('Permintaan tidak sah.');
  const value = CacheService.getScriptCache().get('rsvp-receipt:' + p.ticket);
  if (!value) return { ok: true, pending: true };
  const result = JSON.parse(value);
  result.pending = false;
  return result;
}

function publicError_(error) {
  return { ok: false, message: error && error.publicMessage ? error.message : 'Perkhidmatan RSVP belum tersedia. Sila cuba lagi sebentar.' };
}

function browserReply_(result, callback) {
  if (!callback) return json_(result);
  if (!/^__rsvp_[a-f0-9]{32}$/.test(String(callback))) return json_({ ok: false, message: 'Permintaan tidak sah.' });
  const text = JSON.stringify(result).replace(/[<>&\u2028\u2029]/g, function(char) {
    return '\\u' + ('0000' + char.charCodeAt(0).toString(16)).slice(-4);
  });
  return ContentService.createTextOutput(String(callback) + '(' + text + ');').setMimeType(ContentService.MimeType.JAVASCRIPT);
}

function saveRSVP_(p) {
  const name = String(p.name || '').trim();
  const message = String(p.message || '').trim();
  const attendance = String(p.attendance || '');
  const requestId = String(p.requestId || '');
  if (name.length < 2 || name.length > 80) fail_('Sila masukkan nama antara 2 hingga 80 aksara.');
  if (message.length > 500) fail_('Sila ringkaskan ucapan kepada 500 aksara.');
  if (attendance !== 'hadir' && attendance !== 'tidak_hadir') fail_('Sila pilih status kehadiran anda.');
  if (!/^[A-Za-z0-9-]{20,80}$/.test(requestId)) fail_('Kiriman tidak sah. Sila muat semula halaman.');
  const guests = attendance === 'hadir' ? Number(p.guests) : 0;
  if (attendance === 'hadir' && (!Number.isInteger(guests) || guests < 1 || guests > 5)) fail_('Sila pilih jumlah kehadiran yang tersedia.');
  const status = attendance === 'hadir' ? 'Hadir' : 'Tidak hadir';

  // Mengelakkan dua kiriman serentak menulis rekod yang sama.
  const lock = LockService.getScriptLock();
  if (!lock.tryLock(10000)) fail_('Ramai tetamu sedang menghantar RSVP. Sila cuba lagi sebentar.');
  try {
    const sheet = getSheet_();
    const lastRow = sheet.getLastRow();
    const ids = lastRow > 1 ? sheet.getRange(2, 1, lastRow - 1, 1).getValues() : [];
    const existing = ids.findIndex(function(row) { return String(row[0]) === requestId; });
    if (existing >= 0) {
      const old = sheet.getRange(existing + 2, 1, 1, HEADERS.length).getValues()[0];
      if (plain_(old[2]) !== name || String(old[3]) !== status || Number(old[4]) !== guests || plain_(old[5]) !== message) {
        fail_('Maklumat kiriman telah berubah. Sila muat semula halaman sebelum menghantar.');
      }
      return { ok: true, requestId: requestId, replayed: true };
    }

    const nextRow = lastRow + 1;
    // Input tetamu disimpan sebagai teks, bukan formula spreadsheet.
    sheet.getRange(nextRow, 3).setNumberFormat('@');
    sheet.getRange(nextRow, 6).setNumberFormat('@');
    sheet.getRange(nextRow, 1, 1, HEADERS.length).setValues([[
      requestId, new Date(), safeCell_(name), status, guests, safeCell_(message), 'Ya'
    ]]);
    SpreadsheetApp.flush();
    return { ok: true, requestId: requestId, replayed: false };
  } finally { lock.releaseLock(); }
}

function listWishes_(p) {
  const offset = Number(p.offset || 0);
  const limit = Number(p.limit || 12);
  if (!Number.isInteger(offset) || offset < 0 || offset > 100000) fail_('Pilihan ucapan tidak sah.');
  if (!Number.isInteger(limit) || limit < 1 || limit > 50) fail_('Pilihan ucapan tidak sah.');
  const sheet = getSheet_();
  const rows = sheet.getLastRow() > 1 ? sheet.getRange(2, 1, sheet.getLastRow() - 1, HEADERS.length).getValues() : [];
  const publicWishes = rows.slice().reverse().filter(function(row) {
    const display = String(row[6]).trim().toLowerCase();
    return plain_(row[5]).trim() !== '' && (display === 'ya' || display === 'true' || display === '1');
  });
  const items = publicWishes.slice(offset, offset + limit).map(function(row) {
    const timestamp = row[1] instanceof Date ? row[1] : new Date(row[1]);
    // Hanya nama dan ucapan dipaparkan. Status/jumlah kehadiran kekal dalam Sheets.
    return {
      id: String(row[0]),
      name: plain_(row[2]),
      message: plain_(row[5]),
      date: isNaN(timestamp.getTime()) ? '' : Utilities.formatDate(timestamp, 'Asia/Kuala_Lumpur', 'dd/MM/yyyy')
    };
  });
  return { ok: true, items: items, nextOffset: offset + limit < publicWishes.length ? offset + limit : null };
}

function getSheet_() {
  if (!SPREADSHEET_ID || SPREADSHEET_ID === 'TAMPAL_ID_GOOGLE_SHEETS_DI_SINI') fail_('Perkhidmatan RSVP belum tersedia.');
  const spreadsheet = SpreadsheetApp.openById(SPREADSHEET_ID);
  let sheet = spreadsheet.getSheetByName(SHEET_NAME);
  if (!sheet) sheet = spreadsheet.insertSheet(SHEET_NAME);
  if (sheet.getLastRow() === 0) sheet.getRange(1, 1, 1, HEADERS.length).setValues([HEADERS]);
  const headers = sheet.getRange(1, 1, 1, HEADERS.length).getValues()[0];
  if (HEADERS.some(function(header, index) { return String(headers[index]) !== header; })) fail_('Perkhidmatan RSVP belum tersedia.');
  return sheet;
}

function safeCell_(text) {
  // Awalan ruang sifar tidak kelihatan menjadikan input formula sebagai teks literal.
  // Awalan digandakan jika tetamu sendiri memasukkan aksara itu, supaya boleh dipulihkan tepat.
  return /^[\s]*[=+\-@]/.test(text) || text.charAt(0) === '\u200B' ? '\u200B' + text : text;
}

function plain_(value) {
  const text = String(value || '');
  return text.charAt(0) === '\u200B' ? text.slice(1) : text;
}

function fail_(message) {
  const error = new Error(message);
  error.publicMessage = true;
  throw error;
}

function json_(data) {
  return ContentService.createTextOutput(JSON.stringify(data)).setMimeType(ContentService.MimeType.JSON);
}

// Digunakan oleh Index.html melalui google.script.run.
// Balasan hanya disahkan selepas fungsi doGet selesai.
function rsvpApi(action, data) {
  if (action !== 'list' && action !== 'submit') {
    return { ok: false, message: 'Permintaan tidak sah.' };
  }
  data = data || {};
  if (data.website) return { ok: false, message: 'Kiriman ini tidak dapat diterima.' };
  const parameters = { action: action };
  ['name', 'message', 'attendance', 'guests', 'requestId', 'offset', 'limit'].forEach(function(key) {
    if (data[key] !== undefined && data[key] !== null) parameters[key] = String(data[key]);
  });
  const key = PropertiesService.getScriptProperties().getProperty('RSVP_API_KEY');
  if (key) parameters.key = key;
  return JSON.parse(doGet({ parameter: parameters }).getContent());
}
